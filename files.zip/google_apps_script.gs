/**
 * =====================================================
 *  GameZone BD — Google Apps Script Backend
 *  Version: 1.0 | Production Ready
 * =====================================================
 *
 *  এই স্ক্রিপ্টটি Google Sheets কে database হিসেবে ব্যবহার করে
 *  user signup, login এবং session management পরিচালনা করে।
 *
 *  SETUP: নিচের SHEET_NAME এবং SHEET_ID পরিবর্তন করুন।
 * =====================================================
 */

// ========== CONFIGURATION ==========
const SHEET_NAME = "Users";          // ← Sheet এর tab নাম (পরিবর্তন করবেন না যদি নতুন রাখেন)
const ALLOWED_ORIGIN = "*";          // ← CORS — '*' মানে সব domain থেকে access দেওয়া হবে

// ========== MAIN ENTRY POINT ==========
function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    const action  = payload.action;

    let result;

    if (action === "signup") {
      result = handleSignup(payload);
    } else if (action === "login") {
      result = handleLogin(payload);
    } else {
      result = { status: "error", message: "Unknown action: " + action };
    }

    return buildResponse(result);

  } catch (err) {
    return buildResponse({ status: "error", message: err.toString() });
  }
}

// ========== HANDLE SIGNUP ==========
function handleSignup(data) {
  const { name, email, passwordHash } = data;

  if (!name || !email || !passwordHash) {
    return { status: "error", message: "Missing required fields" };
  }

  const sheet = getSheet();
  const rows  = sheet.getDataRange().getValues();

  // Check if email already exists (skip header row)
  for (let i = 1; i < rows.length; i++) {
    if (rows[i][1] && rows[i][1].toString().toLowerCase() === email.toLowerCase()) {
      return { status: "exists" };
    }
  }

  // Append new user
  const timestamp = new Date().toISOString();
  sheet.appendRow([name, email, passwordHash, timestamp, "active"]);

  return { status: "success", name: name };
}

// ========== HANDLE LOGIN ==========
function handleLogin(data) {
  const { email, passwordHash } = data;

  if (!email || !passwordHash) {
    return { status: "error", message: "Missing email or password" };
  }

  const sheet = getSheet();
  const rows  = sheet.getDataRange().getValues();

  // Search for user (skip header row)
  for (let i = 1; i < rows.length; i++) {
    const rowEmail = rows[i][1] ? rows[i][1].toString().toLowerCase() : "";

    if (rowEmail === email.toLowerCase()) {
      const storedHash = rows[i][2] ? rows[i][2].toString() : "";

      if (storedHash === passwordHash) {
        // Update last login timestamp (column F = index 5)
        sheet.getRange(i + 1, 6).setValue(new Date().toISOString());
        return { status: "success", name: rows[i][0] };
      } else {
        return { status: "invalid" };
      }
    }
  }

  return { status: "notfound" };
}

// ========== SHEET HELPER ==========
function getSheet() {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  let   sheet = ss.getSheetByName(SHEET_NAME);

  // Auto-create sheet with headers if it doesn't exist
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(["Name", "Email", "PasswordHash", "CreatedAt", "Status", "LastLogin"]);

    // Style header row
    const headerRange = sheet.getRange(1, 1, 1, 6);
    headerRange.setFontWeight("bold");
    headerRange.setBackground("#1a0f2e");
    headerRange.setFontColor("#ffd600");
    sheet.setFrozenRows(1);
  }

  return sheet;
}

// ========== CORS RESPONSE BUILDER ==========
function buildResponse(data) {
  const output = ContentService.createTextOutput(JSON.stringify(data));
  output.setMimeType(ContentService.MimeType.JSON);
  return output;
}

// ========== TEST FUNCTION (Development Only) ==========
// এটা Script Editor থেকে manually run করে test করতে পারো
function testSignup() {
  const result = handleSignup({
    name: "Test User",
    email: "test@gamezone.bd",
    passwordHash: "abc123fakehash"
  });
  Logger.log(JSON.stringify(result));
}

function testLogin() {
  const result = handleLogin({
    email: "test@gamezone.bd",
    passwordHash: "abc123fakehash"
  });
  Logger.log(JSON.stringify(result));
}
